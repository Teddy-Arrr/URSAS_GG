import css from './index.module.css'

interface props
{

}

export default (props: props) => {
    return <div className={ css.loader }>
        <div className={ css.inner }>
        </div>
    </div>
}